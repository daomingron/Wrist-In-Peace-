CREATE DATABASE watch_inventory;

USE watch_inventory;

CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

INSERT INTO admin (username, password)
VALUES ('admin', 'admin 123');

CREATE TABLE watches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    stock INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    photo VARCHAR(255)
);

INSERT INTO watches (brand, model, stock, price) VALUES
('Rolex', 'Submariner', 5, 850000),
('Patek Philippe', 'Nautilus', 2, 2500000),
('Richard Mille', 'RM 011', 1, 7500000);