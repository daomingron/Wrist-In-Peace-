<?php
require 'config.php';
ensureLoggedIn();

$inventory = getInventoryItems();
$stockTotal = array_reduce($inventory, static fn($sum, $item) => $sum + (int)($item['stockQuantity'] ?? 0), 0);
$valueTotal = array_reduce($inventory, static fn($sum, $item) => $sum + ((float)($item['unitPrice'] ?? 0) * (int)($item['stockQuantity'] ?? 0)), 0.0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Summary</title>
    <link rel="stylesheet" href="../styles.css" />
</head>
<body>
    <div class="app-shell">
        <aside class="sidebar">
            <div class="brand-block">
                <div class="brand-badge">CB</div>
                <div>
                    <h1>Wrist In Peace</h1>
                    <p>Admin summary</p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <div class="nav-group">
                    <p class="nav-heading">Navigation</p>
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                    <a class="nav-link" href="admin.php">Inventory Summary</a>
                    <a class="nav-link" href="logout.php">Sign Off</a>
                </div>
            </nav>
        </aside>
        <div class="content-panel">
            <header class="topbar">
                <div>
                    <p class="topbar-kicker">Admin overview</p>
                    <h2>Inventory Summary</h2>
                </div>
                <div class="topbar-actions">
                    <a class="btn btn-secondary" href="dashboard.php">Back</a>
                    <a class="btn btn-primary" href="index.html">Open App</a>
                </div>
            </header>
            <main class="main-content">
                <div class="card info-card">
                    <h3>Inventory totals</h3>
                    <p>Total stock units: <?php echo $stockTotal; ?></p>
                    <p>Total inventory value: ₱<?php echo number_format($valueTotal, 2); ?></p>
                </div>
                <div class="table-card">
                    <table>
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Category</th>
                                <th>Stock</th>
                                <th>Price</th>
                                <th>Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($inventory as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['itemName'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($item['category'] ?? ''); ?></td>
                                    <td><?php echo (int)($item['stockQuantity'] ?? 0); ?></td>
                                    <td>₱<?php echo number_format((float)($item['unitPrice'] ?? 0), 2); ?></td>
                                    <td>₱<?php echo number_format(((float)($item['unitPrice'] ?? 0)) * ((int)($item['stockQuantity'] ?? 0)), 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
