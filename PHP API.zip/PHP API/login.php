<?php
require 'config.php';

if (isset($_SESSION['admin'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Wrist In Peace Login</title>
    <link rel="stylesheet" href="../styles.css" />
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, #07111f, #203658 55%, #355b85);
            color: #f8fafc;
            padding: 24px;
        }
        .login-card {
            width: min(92vw, 430px);
            background: rgba(255, 255, 255, 0.74);
            backdrop-filter: blur(16px);
            color: #0f172a;
            padding: 28px;
            border-radius: 24px;
            box-shadow: 0 24px 60px rgba(2, 6, 23, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.45);
        }
        .login-card h1 { margin-top: 0; font-size: 1.8rem; }
        .login-card form { display: grid; gap: 12px; }
        .login-card input { width: 100%; padding: 10px 12px; border-radius: 12px; border: 1px solid rgba(15, 23, 42, 0.12); background: rgba(255, 255, 255, 0.9); color: #0f172a; }
        .login-card button { width: 100%; border-radius: 999px; }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>Wrist In Peace</h1>
        <p>Sign in to manage the catalog and review inventory totals.</p>
        <form id="login-form">
            <input id="username-input" type="text" name="username" placeholder="Username" required />
            <input id="password-input" type="password" name="password" placeholder="Password" required />
            <button class="btn btn-primary" type="submit">Login</button>
        </form>
    </div>
    <script>
        const loginForm = document.getElementById('login-form');
        const usernameInput = document.getElementById('username-input');
        const passwordInput = document.getElementById('password-input');

        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();

            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();

            if (username === 'admin' && password === 'admin 123') {
                localStorage.setItem('watchInventoryAuth', 'true');
                localStorage.setItem('watchInventoryUser', username);
                window.location.href = 'index.html';
            } else {
                alert('Invalid username or password.');
            }
        });
    </script>
</body>
</html>
