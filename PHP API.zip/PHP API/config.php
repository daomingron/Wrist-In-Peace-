<?php
session_start();

$inventoryFile = __DIR__ . '/inventory_data.json';

function loadInventoryItems(): array
{
    global $inventoryFile;

    if (!file_exists($inventoryFile)) {
        return [];
    }

    $content = file_get_contents($inventoryFile);
    $data = json_decode($content, true);

    return is_array($data) ? $data : [];
}

function saveInventoryItems(array $items): void
{
    global $inventoryFile;

    $encoded = json_encode($items, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    file_put_contents($inventoryFile, $encoded);

    if (!isset($_SESSION['session_inventory']) || !is_array($_SESSION['session_inventory'])) {
        $_SESSION['session_inventory'] = [];
    }

    $_SESSION['session_inventory'] = $items;
}

function getInventoryItems(): array
{
    if (!isset($_SESSION['session_inventory']) || !is_array($_SESSION['session_inventory'])) {
        $_SESSION['session_inventory'] = loadInventoryItems();
    }

    return $_SESSION['session_inventory'];
}

function ensureLoggedIn(): void
{
    if (!isset($_SESSION['admin'])) {
        header('Location: login.php');
        exit;
    }
}
