<?php
require 'config.php';
ensureLoggedIn();

$inventory = getInventoryItems();
$stockTotal = array_reduce($inventory, static fn($sum, $item) => $sum + (int)($item['stockQuantity'] ?? 0), 0);
$valueTotal = array_reduce($inventory, static fn($sum, $item) => $sum + ((float)($item['unitPrice'] ?? 0) * (int)($item['stockQuantity'] ?? 0)), 0.0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard</title>
    <link rel="stylesheet" href="../styles.css" />
</head>
<body>
    <div class="app-shell">
        <aside class="sidebar">
            <div class="brand-block">
                <div class="brand-badge">CB</div>
                <div>
                    <h1>Wrist In Peace</h1>
                    <p>PHP admin panel</p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <div class="nav-group">
                    <p class="nav-heading">Workspace</p>
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                    <a class="nav-link" href="admin.php">Inventory Summary</a>
                    <a class="nav-link" href="logout.php">Sign Off</a>
                </div>
            </nav>
        </aside>
        <div class="content-panel">
            <header class="topbar">
                <div>
                    <p class="topbar-kicker">Server-side dashboard</p>
                    <h2>Welcome back, <?php echo htmlspecialchars($_SESSION['admin']); ?></h2>
                </div>
                <div class="topbar-actions">
                    <a class="btn btn-secondary" href="index.html">Open the SPA dashboard</a>
                    <a class="btn btn-primary" href="admin.php">Admin Summary</a>
                </div>
            </header>
            <main class="main-content">
                <section class="hero-card">
                    <div>
                        <p class="eyebrow">Live overview</p>
                        <h3>Inventory control is now backed by PHP sessions and storage.</h3>
                        <p>You can continue using the dashboard app in the browser and manage records from the PHP admin pages.</p>
                    </div>
                    <div class="hero-stat">
                        <span>Items in stock</span>
                        <strong><?php echo count($inventory); ?></strong>
                    </div>
                </section>

                <div class="card info-card">
                    <h3>Quick inventory snapshot</h3>
                    <p>Total units: <?php echo $stockTotal; ?></p>
                    <p>Total value: ₱<?php echo number_format($valueTotal, 2); ?></p>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
