<?php
require 'config.php';

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === 'admin' && $password === 'admin123') {
    $_SESSION['admin'] = $username;
    $_SESSION['first_login'] = true;
    $_SESSION['session_inventory'] = loadInventoryItems();

    $redirect = $_GET['redirect'] ?? 'index.html';
    if (isset($_POST['redirect']) && !empty($_POST['redirect'])) {
        $redirect = $_POST['redirect'];
    }

    header('Location: ' . $redirect);
    exit;
}

http_response_code(401);
echo '<!DOCTYPE html><html><body><h2>Invalid username or password.</h2><p><a href="login.php">Try again</a></p></body></html>';
